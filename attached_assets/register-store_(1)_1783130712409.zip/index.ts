import { createClient } from "https://esm.sh/@supabase/supabase-js@2.43.4";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

interface RegisterStoreRequest {
  storeName: string;
  description?: string;
  marketType?: string;
  storeType?: string; // 🟢 1. أضفنا الحقل هنا لاستقباله من الفرونت إند
  location?: string;
  whatsappNumber: string;
  ownerName: string;
  ownerEmail: string;
  password?: string;
  packageId: string;
  registeredByAgentId?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { status: 200, headers: CORS_HEADERS });
  }

  try {
    if (req.method !== "POST") {
      return new Response(
        JSON.stringify({ success: false, error: "Method not allowed" }),
        { status: 405, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }

    const body: RegisterStoreRequest = await req.json();

    if (!body.storeName || !body.ownerName || !body.ownerEmail || !body.packageId || !body.whatsappNumber) {
      return new Response(
        JSON.stringify({ success: false, error: "Missing required fields" }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing Supabase environment configuration");
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // جلب بيانات الباقة
    const { data: packageData, error: packageError } = await supabase
      .from("store_packages")
      .select("*")
      .eq("id", body.packageId)
      .single();

    if (packageError || !packageData) {
      return new Response(
        JSON.stringify({ success: false, error: "Selected package not found" }),
        { status: 404, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }

    const storeId = crypto.randomUUID();
    const generatedPassword = body.password || crypto.randomUUID().substring(0, 12);

    // 1️⃣ أولاً: إنشاء حساب المالك في الـ Auth Admin
    const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
      email: body.ownerEmail,
      password: generatedPassword,
      email_confirm: true,
      user_metadata: { name: body.ownerName, role: "store" },
    });

    if (authError || !authUser.user) {
      return new Response(
        JSON.stringify({ success: false, error: `Auth creation failed: ${authError?.message}` }),
        { status: 400, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
      );
    }

    const authUserId = authUser.user.id;

    // 2️⃣ ثانياً: إنشاء سجل المتجر أولاً (stores)
    const { data: newStore, error: storeTableError } = await supabase
      .from("stores")
      .insert({
        id: storeId,
        name: body.storeName,
        description: body.description || null,
        
        type: body.storeType || null, // 🟢 2. مررنا القيمة هنا ليتم حفظها في قاعدة البيانات
        
        market_type: body.marketType || null,
        marketType: body.marketType || null,
        location: body.location || null,
        whatsapp_number: body.whatsappNumber,
        whatsappNumber: body.whatsappNumber,
        is_active: false,
        isActive: false,
        product_limit: packageData.product_limit,
        productLimit: packageData.product_limit,
        subscription_duration: packageData.subscription_duration,
        subscriptionDuration: packageData.subscription_duration,
        owner_id: authUserId,
        ownerId: authUserId,
        owner_email: body.ownerEmail,
        ownerEmail: body.ownerEmail,
        password: generatedPassword,
        package_name: packageData.name,
        packageName: packageData.name,
        package_id: body.packageId,
        registered_by_agent_id: body.registeredByAgentId || null,
        registeredByAgentId: body.registeredByAgentId || null,
        rating: 0,
        reviews: 0,
      })
      .select("*")
      .single();

    if (storeTableError) {
      await supabase.auth.admin.deleteUser(authUserId);
      throw new Error(`Failed to create row in stores table: ${storeTableError.message}`);
    }

    // 3️⃣ ثالثاً: إدخال المالك في جدول الـ users
    const { error: userTableError } = await supabase
      .from("users")
      .insert({
        id: authUserId,
        name: body.ownerName,
        email: body.ownerEmail,
        role: "store",
        store_id: storeId,
        storeId: storeId,
        first_login: true,
        firstLogin: true,
      });

    if (userTableError) {
      await supabase.from("stores").delete().eq("id", storeId);
      await supabase.auth.admin.deleteUser(authUserId);
      throw new Error(`Failed to create row in users table: ${userTableError.message}`);
    }

    // 4️⃣ رابعاً: توثيق العملية في الـ Audit Log
    await supabase.from("subscription_audit_log").insert({
      store_id: storeId,
      storeId: storeId,
      action: "store_signup",
      status_before: null,
      statusBefore: null,
      status_after: "pending_payment",
      statusAfter: "pending_payment",
      details: { package_id: body.packageId, package_name: packageData.name },
      actor_id: authUserId,
      actorId: authUserId,
      actor_type: "store",
      actorType: "store",
    });

    return new Response(
      JSON.stringify({
        success: true,
        message: "Store and owner profile registered successfully.",
        storeId: newStore.id,
        ownerId: authUserId,
        ownerEmail: body.ownerEmail,
        packageName: packageData.name,
        amountToPay: packageData.price,
      }),
      { status: 201, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Unexpected error:", error);
    return new Response(
      JSON.stringify({
        success: false,
        message: "Internal server error during store establishment",
        error: error instanceof Error ? error.message : String(error),
      }),
      { status: 500, headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
    );
  }
});