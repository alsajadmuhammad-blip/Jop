import { serve } from "https://deno.land/std@0.178.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

const DEFAULT_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
  },
});

function buildResponse(body: any, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: DEFAULT_HEADERS,
  });
}

function normalizeString(value: any): string {
  return typeof value === "string" ? value.trim() : "";
}

function parseBoolean(value: any): boolean {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value === 1;
  if (typeof value === "string") {
    const normalized = value.trim().toLowerCase();
    return ["1", "true", "t", "yes", "y"].includes(normalized);
  }
  return false;
}

interface CreateProductPayload {
  storeId: string;
  name: string;
  description: string;
  price: number;
  sectionId: string;
  sku?: string | null;
  stock?: number;
  imageUrl?: string | null;
  isFeatured?: boolean;
}

function validatePayload(body: any): CreateProductPayload {
  if (!body || typeof body !== "object") {
    throw new Error("Payload must be a JSON object.");
  }

  const storeId = normalizeString(body.storeId ?? body.store_id);
  const name = normalizeString(body.name);
  const description = normalizeString(body.description);
  const price =
    typeof body.price === "string" ? Number(body.price) : body.price;
  const sectionId = normalizeString(
    body.sectionId ??
      body.section_id ??
      body.categoryId ??
      body.category_id
  );
  const sku =
    body.sku != null
      ? normalizeString(body.sku)
      : body.productSku != null
      ? normalizeString(body.productSku)
      : null;
  const stock =
    typeof body.stock === "string"
      ? Number(body.stock)
      : typeof body.stock === "number"
      ? body.stock
      : 0;
  const imageUrl =
    body.imageUrl != null
      ? normalizeString(body.imageUrl)
      : body.image_url != null
      ? normalizeString(body.image_url)
      : null;
  const isFeatured = parseBoolean(
    body.isFeatured ?? body.is_featured ?? false
  );

  if (!storeId) throw new Error("storeId is required.");
  if (!name || name.length < 3)
    throw new Error("name is required and must be at least 3 characters.");
  if (!description || description.length < 10)
    throw new Error(
      "description is required and must be at least 10 characters."
    );
  if (typeof price !== "number" || Number.isNaN(price) || price <= 0)
    throw new Error("price is required and must be a positive number.");
  if (!sectionId) throw new Error("sectionId is required.");

  return {
    storeId,
    name,
    description,
    price,
    sectionId,
    sku: sku || null,
    stock: Number.isNaN(stock) ? 0 : stock,
    imageUrl: imageUrl || null,
    isFeatured,
  };
}

async function getStore(storeId: string) {
  const { data, error } = await supabase
    .from("stores")
    .select("id, is_active, product_limit")
    .eq("id", storeId)
    .maybeSingle();

  if (error) {
    throw new Error(`Failed to validate store: ${error.message}`);
  }
  if (!data) {
    throw new Error("Store not found.");
  }

  return {
    id: data.id as string,
    isActive: parseBoolean(data.is_active),
    productLimit:
      typeof data.product_limit === "number" ? data.product_limit : null,
  };
}

async function validateSection(storeId: string, sectionId: string) {
  const { data, error } = await supabase
    .from("store_sections")
    .select("id")
    .eq("id", sectionId)
    .eq("store_id", storeId)
    .maybeSingle();

  if (error) {
    throw new Error(`Failed to validate section: ${error.message}`);
  }
  if (!data) {
    throw new Error("Section not found for this store.");
  }
}

async function countProductsForStore(storeId: string) {
  const { count, error } = await supabase
    .from("products")
    .select("id", { count: "exact", head: true })
    .eq("store_id", storeId);

  if (error) {
    throw new Error(`Failed to count products for store: ${error.message}`);
  }
  return typeof count === "number" ? count : 0;
}

async function createProduct(payload: CreateProductPayload) {
  const row: any = {
    store_id: payload.storeId,
    storeId: payload.storeId,
    section_id: payload.sectionId,
    sectionId: payload.sectionId,
    name: payload.name,
    description: payload.description,
    price: payload.price,
    sku: payload.sku,
    stock: payload.stock ?? 0,
    image_url: payload.imageUrl,
    imageUrl: payload.imageUrl,
    is_featured: payload.isFeatured,
    isFeatured: payload.isFeatured,
  };

  const { data, error } = await supabase
    .from("products")
    .insert(row)
    .select("*")
    .single();

  if (error) {
    throw new Error(`Failed to create product: ${error.message}`);
  }

  return data;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: DEFAULT_HEADERS });
  }

  if (req.method !== "POST") {
    return buildResponse(
      { success: false, error: "Method not allowed. Use POST." },
      405
    );
  }

  try {
    const payload = validatePayload(await req.json());

    const store = await getStore(payload.storeId);
    if (!store.isActive) {
      throw new Error(
        "Store is not active. لا يمكن إضافة منتج إلى متجر غير مفعل."
      );
    }

    await validateSection(payload.storeId, payload.sectionId);

    const currentCount = await countProductsForStore(payload.storeId);
    if (store.productLimit != null && currentCount >= store.productLimit) {
      throw new Error(
        `Product limit reached. الحد الأقصى لعدد المنتجات هو ${store.productLimit}.`
      );
    }

    const product = await createProduct(payload);
    return buildResponse({ success: true, product }, 201);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error.";
    console.error("Create product function error:", errorMessage);
    return buildResponse({ success: false, error: errorMessage }, 400);
  }
});