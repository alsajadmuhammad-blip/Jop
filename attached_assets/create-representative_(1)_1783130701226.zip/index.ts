import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

interface CreateRepresentativePayload {
  name: string
  email: string
  password: string
  paymentSystem: 'salary' | 'commission'
  monthlySalary?: number
  requiredStoresCount?: number
}

interface CreateRepresentativeResult {
  success: boolean
  userId?: string
  representative?: any
  error?: string
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {

  // CORS PREFLIGHT
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: corsHeaders,
    })
  }

  // METHOD VALIDATION
  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      {
        status: 405,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    )
  }

  try {

    const body = await req.json()

    const payload: CreateRepresentativePayload = {
      name: body.name || body.full_name || body.fullName,
      email: body.email,
      password: body.password,
      paymentSystem: body.paymentSystem || body.payment_system,
      monthlySalary:
        body.monthlySalary ?? body.monthly_salary,
      requiredStoresCount:
        body.requiredStoresCount ?? body.required_stores_count,
    }

    // VALIDATION
    if (
      !payload.name ||
      !payload.email ||
      !payload.password ||
      !payload.paymentSystem
    ) {
      return new Response(
        JSON.stringify({
          success: false,
          error:
            'Missing required representative fields: name, email, password, paymentSystem',
        }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      )
    }

    // SALARY VALIDATION
    if (payload.paymentSystem === 'salary') {

      if (
        payload.monthlySalary === undefined ||
        payload.requiredStoresCount === undefined
      ) {

        return new Response(
          JSON.stringify({
            success: false,
            error:
              'Salary representatives must include monthlySalary and requiredStoresCount',
          }),
          {
            status: 400,
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json',
            },
          }
        )
      }
    }

    // SUPABASE
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey =
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

    const supabase = createClient(
      supabaseUrl,
      supabaseServiceKey
    )

    // CREATE AUTH USER
    const {
      data: authData,
      error: authError,
    } = await supabase.auth.admin.createUser({
      email: payload.email,
      password: payload.password,
      email_confirm: true,
      user_metadata: {
        full_name: payload.name,
      },
    })

    if (authError || !authData?.user?.id) {

      console.error('AUTH ERROR:', authError)

      return new Response(
        JSON.stringify({
          success: false,
          error:
            authError?.message ||
            'Failed to create auth user',
        }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      )
    }

    const userId = authData.user.id

    // REPRESENTATIVE DATA
    const representativeData = {
      id: userId,
      name: payload.name,
      email: payload.email,
      role: 'representative',
      payment_system: payload.paymentSystem,
      monthly_salary:
        payload.paymentSystem === 'salary'
          ? payload.monthlySalary
          : 0,
      required_stores_count:
        payload.paymentSystem === 'salary'
          ? payload.requiredStoresCount
          : 0,
      total_earnings: 0,
      monthly_activations: 0,
      first_login: true,
    }

    // INSERT USER
    const { error: userError } = await supabase
      .from('users')
      .insert([representativeData])

    if (userError) {

      console.error('DATABASE ERROR:', userError)

      // ROLLBACK AUTH USER
      await supabase.auth.admin.deleteUser(userId)

      return new Response(
        JSON.stringify({
          success: false,
          error: userError.message,
        }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      )
    }

    // SUCCESS
    return new Response(
      JSON.stringify({
        success: true,
        userId,
        representative: representativeData,
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    )

  } catch (error: any) {

    console.error('SERVER ERROR:', error)

    return new Response(
      JSON.stringify({
        success: false,
        error:
          error?.message || 'Unknown server error',
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    )
  }
})
